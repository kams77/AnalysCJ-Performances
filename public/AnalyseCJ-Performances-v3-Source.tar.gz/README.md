# Analyse C&J Performances (Web & Autonomous Big Data)

Application d'analyse experte des **cartons jaunes** et **corners** de football par croisement statistique déterministe et Big Data 2026 (Loi de Poisson, sévérité arbitrale, conformité ngengesport.cd RDC).

---

## 🚀 Téléchargement du Projet

### 1. Télécharger le Code Source (ZIP)
1. Rendez-vous sur la page GitHub du projet : [https://github.com/kams77/AnalysCJ-Performances](https://github.com/kams77/AnalysCJ-Performances)
2. Cliquez sur le bouton vert **`<> Code`** en haut à droite.
3. Cliquez sur **`Download ZIP`** (Télécharger le ZIP).
4. Décompressez l'archive sur votre ordinateur !

### 2. Télécharger l'Application Mobile APK (pour téléphone Android)
1. Sur GitHub, cliquez sur l'onglet **`Actions`** en haut de la page.
2. Cliquez sur le dernier workflow exécuté nommé **`Build APK`** (ou équivalent).
3. En bas de page dans la section **`Artifacts`**, cliquez sur **`AnalysCJ-Performances-debug-apk`**.
4. Vous obtenez le fichier `app-debug.apk` à installer directement sur votre smartphone Android.

---

## ⚡ Démarrage Rapide en Local (Web)

```bash
# 1. Installer les dépendances
npm install

# 2. Lancer le serveur local
npm run dev

# L'application est disponible sur http://localhost:3000
```

---

## 📊 Fonctionnalités Clés & Conformité ngengesport.cd

- **Moteur Autonome 2026** : Calcul déterministe sans clé API requise, modélisation de Poisson sur 6 championnats européens.
- **Filtrage Strict $\ge 80\%$** : Aucune sélection n'est qualifiée si elle n'atteint pas un seuil mathématique garanti de 80% de probabilité.
- **Règlementation ngengesport.cd (RDC Congo)** : Seuls les cartons jaunes donnés aux joueurs sur le terrain durant le temps réglementaire (90 min) sont comptabilisés.
- **💰 Calculateur de Mise en Francs Congolais (CDF)** : Mises rapides (1k à 50k CDF), gains bruts, bénéfices nets et conversion USD (~2 800 CDF/USD).
- **📲 Exportations HD & Partage Réseaux** : Téléchargement en Image HD (PNG), impression / sauvegarde PDF du ticket, partage immédiat sur WhatsApp et Telegram.
- **🎯 Suivi des Résultats & Comparateur Automatique** : Saisie du score réel de match (corners tirés, cartons reçus), validation automatique des lignes de pronostics et calcul de la rentabilité réelle.
- **🎟️ Panier Combiné Multi-Matchs (2 à 5 Matchs)** : Création de super-tickets combinés multi-rencontres avec calcul de super-cote cumulée et export dédié.
- **🚨 Détecteur de Matchs Pièges & Derbys** : Reconnaissance automatique des derbys à haute tension (PSG-OM, El Clásico, Derbi Madrileño, etc.) et analyse de l'impact météo.
- **👤 Fiche Détaillée Profil Arbitre** : Jauge visuelle de sévérité, comparaison avec la moyenne du championnat, et répartition 1ère / 2ème mi-temps.

